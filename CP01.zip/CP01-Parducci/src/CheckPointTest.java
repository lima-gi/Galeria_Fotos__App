import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

public class CheckPointTest {

	@Test
	public void test1() throws IOException {
		int indicador = 1;
		
	   CheckPoint value = new CheckPoint();
       int resultadovalues = value.capturaNro('n');
       assertEquals(indicador,resultadovalues);
       
       }
}
