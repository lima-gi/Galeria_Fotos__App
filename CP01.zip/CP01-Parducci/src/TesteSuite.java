import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({CheckPointTest.class,CheckPoint2Test.class })
public class TesteSuite {

}
