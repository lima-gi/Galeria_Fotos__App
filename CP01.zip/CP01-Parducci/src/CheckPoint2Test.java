import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

public class CheckPoint2Test {

		@Test
		public void test2() throws IOException {
			int indicador = 1;
			 CheckPoint value = new CheckPoint();
		       int resultadovalues = CheckPoint.capturaNro('n');
		       assertEquals(indicador,resultadovalues);
					
	       }

		@Test
		public void test3() throws IOException {
			int indicador = 1;
			 CheckPoint value = new CheckPoint();
		       int resultadovalues = CheckPoint.capturaNro('n');
		       assertEquals(indicador,resultadovalues);
					
	       }

}
